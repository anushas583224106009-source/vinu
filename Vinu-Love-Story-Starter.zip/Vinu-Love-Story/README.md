# Vinu — Our Five-Year Love Story

## Requirements
- Node.js LTS (install from https://nodejs.org if not already installed)
- VS Code

## Run on Windows PowerShell
Open PowerShell in this folder and run:

```powershell
npm install
npm run dev
```

Open the Local URL printed by Vite, usually `http://localhost:5173`.

## Add your memories
- Add five photos to `public/memories/` named `year-1.jpg` through `year-5.jpg`.
- Optional: add `video-poster.jpg`.
- Add your audio as `public/media/our-song.mp3`.
- Add your video as `public/media/our-video.mp4`.
- Edit chapter titles, dates, captions, and letter in `src/App.jsx`.
- Change the entrance word at the top of `src/App.jsx`: `const PASSWORD = 'vinu';`

## Important privacy note
The password gate is only a front-end entrance effect. Anyone with technical knowledge can bypass it, and files on a public static host may be accessible by URL. Do not use it to protect sensitive photos/videos. For real access control, add a server-side authentication service and private storage.

## Build test
```powershell
npm run build
npm run preview
```

## Publish
After it works locally, deploy the project using a static hosting provider such as Netlify or Vercel. The deploy flow and privacy setup can be done next.
