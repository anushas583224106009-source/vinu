import React, { useEffect, useRef, useState } from 'react';
import { Heart, LockKeyhole, Music2, Volume2, VolumeX, Play, Pause, ChevronDown, Sparkles, Stars, MailOpen, Gift } from 'lucide-react';

const PASSWORD = 'vinu'; // Change this. This is a cute entrance gate, not secure authentication.
const years = [
  { year: 'YEAR ONE', title: 'The beginning of us', date: 'Our first chapter', copy: 'The year a little hello became something precious. Add the memory that started it all here.', image: '/memories/year-1.jpg' },
  { year: 'YEAR TWO', title: 'Learning each other', date: 'Little things, big feelings', copy: 'The inside jokes, the long talks, and all the little things that slowly became ours.', image: '/memories/year-2.jpg' },
  { year: 'YEAR THREE', title: 'My favourite memories', date: 'A chapter full of us', copy: 'Add the day you wish you could relive, the photo that still makes you smile, and the story behind it.', image: '/memories/year-3.jpg' },
  { year: 'YEAR FOUR', title: 'Through everything', date: 'Still choosing you', copy: 'Not every chapter has to be perfect. The important part is what you learned and what you mean to each other.', image: '/memories/year-4.jpg' },
  { year: 'YEAR FIVE', title: 'Five years, still you', date: 'And our story continues', copy: 'Five years of memories, and still so much left to experience together. This is not the ending.', image: '/memories/year-5.jpg' }
];

function App() {
  const [unlocked, setUnlocked] = useState(false);
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [playing, setPlaying] = useState(false);
  const [letterOpen, setLetterOpen] = useState(false);
  const [surprise, setSurprise] = useState(false);
  const audioRef = useRef(null);

  useEffect(() => {
    if (playing && audioRef.current) audioRef.current.play().catch(() => setPlaying(false));
    else if (audioRef.current) audioRef.current.pause();
  }, [playing]);

  const unlock = (e) => {
    e.preventDefault();
    if (password.trim().toLowerCase() === PASSWORD) {
      setUnlocked(true); setError('');
    } else setError('Not quite, my love. Try your special word again. ♡');
  };

  return (
    <main>
      <audio ref={audioRef} src="/media/our-song.mp3" loop preload="none" />
      {!unlocked ? (
        <section className="gate">
          <div className="grain" />
          <div className="gate-glow" />
          <div className="gate-card">
            <div className="mini-heart"><Heart fill="currentColor" size={18}/></div>
            <p className="eyebrow">A LITTLE WORLD, MADE FOR ONE PERSON</p>
            <h1>Only for <em>Vinu.</em></h1>
            <p className="gate-copy">Five years. A thousand memories.<br/>One person I would choose again.</p>
            <form onSubmit={unlock} className="password-form">
              <label htmlFor="secret">Our little secret</label>
              <div className="password-wrap"><LockKeyhole size={17}/><input id="secret" value={password} onChange={e => setPassword(e.target.value)} placeholder="Enter the secret word" autoComplete="off" /></div>
              <button className="primary-button" type="submit">OPEN MY HEART <Heart size={15}/></button>
              {error && <p className="error" role="alert">{error}</p>}
            </form>
            <p className="gate-foot">MADE WITH LOVE, JUST FOR YOU ♡</p>
          </div>
        </section>
      ) : (
        <>
          <nav className="nav">
            <a className="brand" href="#home"><Heart size={17} fill="currentColor"/> OUR LITTLE UNIVERSE</a>
            <button className="music-button" onClick={() => setPlaying(v => !v)} aria-label={playing ? 'Pause music' : 'Play music'}>
              {playing ? <Pause size={16}/> : <Play size={16}/>} {playing ? 'Pause our song' : 'Play our song'}
            </button>
          </nav>
          <section id="home" className="hero">
            <div className="hero-orb orb-one"/><div className="hero-orb orb-two"/>
            <div className="hero-content">
              <p className="eyebrow"><Sparkles size={14}/> FIVE YEARS OF US <Sparkles size={14}/></p>
              <h1>In every lifetime,<br/>I'd still find <em>you.</em></h1>
              <p className="hero-copy">Dear Vinu, this is a little journey through the moments that made us… us.</p>
              <a className="primary-button link-button" href="#timeline">WALK DOWN MEMORY LANE <ChevronDown size={16}/></a>
              <div className="hero-signature">with all my love <Heart size={14} fill="currentColor"/></div>
            </div>
            <div className="hero-bottom">SCROLL SLOWLY · EVERY MEMORY MATTERS</div>
          </section>

          <section className="intro section-pad">
            <p className="eyebrow">TO MY FAVOURITE PERSON</p>
            <h2>Some stories are written.<br/><em>Ours is lived.</em></h2>
            <p className="intro-copy">Five years cannot fit into one page. But I wanted to collect a few pieces of our world here, so whenever you miss us, you can come back to this little place.</p>
            <div className="stat-row"><div><strong>05</strong><span>YEARS OF US</span></div><i/><div><strong>∞</strong><span>MEMORIES TO COME</span></div><i/><div><strong>1</strong><span>FAVOURITE PERSON</span></div></div>
          </section>

          <section id="timeline" className="timeline-section section-pad">
            <div className="section-heading"><p className="eyebrow">CHAPTERS OF OUR STORY</p><h2>Five years.<br/><em>Five little worlds.</em></h2><p>Replace the sample words and photos with your real memories.</p></div>
            <div className="timeline">
              {years.map((item, i) => <article className={`memory-card ${i % 2 ? 'reverse' : ''}`} key={item.year}>
                <div className="memory-image-wrap">
                  <img src={item.image} alt={`Memory from ${item.year.toLowerCase()}`} onError={e => { e.currentTarget.style.display='none'; e.currentTarget.parentElement.classList.add('image-placeholder'); }} />
                  <div className="image-placeholder-label"><Heart size={24}/><span>YOUR PHOTO GOES HERE</span><small>{item.year}</small></div>
                  <span className="photo-number">0{i+1} / 05</span>
                </div>
                <div className="memory-text"><p className="eyebrow">{item.year}</p><h3>{item.title}</h3><p className="memory-date">{item.date}</p><p>{item.copy}</p><span className="tiny-heart"><Heart size={14} fill="currentColor"/></span></div>
              </article>)}
            </div>
          </section>

          <section className="video-section section-pad">
            <div className="section-heading"><p className="eyebrow">LITTLE MOMENTS, FOREVER</p><h2>Press play.<br/><em>Remember us.</em></h2><p>Add a favourite video in the file shown in the setup guide.</p></div>
            <div className="video-frame">
              <video controls playsInline preload="metadata" poster="/memories/video-poster.jpg">
                <source src="/media/our-video.mp4" type="video/mp4"/>
                Your browser does not support embedded video.
              </video>
              <div className="video-caption"><Heart size={15} fill="currentColor"/> A little piece of forever</div>
            </div>
          </section>

          <section className="letter-section section-pad">
            <div className="letter-decoration"><MailOpen size={28}/></div>
            <p className="eyebrow">SOMETHING I NEED YOU TO KNOW</p>
            <h2>A letter for <em>you.</em></h2>
            <p className="letter-intro">Some feelings deserve more than a message on a screen.</p>
            {!letterOpen ? <button className="primary-button" onClick={() => setLetterOpen(true)}>OPEN YOUR LETTER <MailOpen size={16}/></button> :
              <article className="letter-paper">
                <p className="letter-date">TO MY VINU, WITH LOVE ♡</p>
                <p>My Vinu,</p>
                <p>Five years ago, I had no idea how many memories, smiles, lessons, and feelings would become part of our story. Somewhere along the way, you became a very special part of my world.</p>
                <p>Thank you for the moments that made me laugh, the memories I keep replaying, and the little things that mean more than I can explain. No website could ever hold everything I feel, but I wanted to make this small place just for us.</p>
                <p>On your birthday, I hope you feel how loved and important you are. Whatever new chapters come next, I hope we keep finding reasons to smile, keep making memories, and keep choosing the moments that matter.</p>
                <p>Happy birthday, my love. This is five years of us — and I hope there are so many beautiful pages still waiting to be written.</p>
                <p className="letter-sign">Always yours, ♡</p>
                <p className="edit-note">Personalise this letter in src/App.jsx before sharing.</p>
              </article>}
          </section>

          <section className="final-section section-pad">
            <div className="final-stars"><Stars size={24}/></div>
            <p className="eyebrow">AND NOW, THE MOST IMPORTANT PART</p>
            <h2>Happy Birthday,<br/><em>my Vinu.</em></h2>
            <p className="final-copy">If I could give you one thing, it would be the chance to see yourself through my eyes — then you would know how special you are to me.</p>
            <button className="surprise-button" onClick={() => setSurprise(true)}><Gift size={18}/> {surprise ? 'MY WISH FOR YOU' : 'ONE LAST LITTLE SURPRISE'}</button>
            {surprise && <div className="surprise-message"><div className="confetti-hearts">♡ ✦ ♡ ✧ ♡</div><h3>My wish is simple…</h3><p>May this year bring you peace, courage, happiness, and every beautiful thing your heart is hoping for. And may you always remember that someone is cheering for you, loving you, and wishing the very best for you.</p><strong>Happy birthday, Vinu. I love you. ♡</strong></div>}
          </section>
          <footer><Heart size={13} fill="currentColor"/> MADE FOR VINU, WITH LOVE <span>·</span> OUR STORY CONTINUES</footer>
        </>
      )}
    </main>
  );
}

export default App;